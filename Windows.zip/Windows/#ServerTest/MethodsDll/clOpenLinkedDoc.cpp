#define INFO_BUFFER_SIZE 32767
#include "clOpenLinkedDoc.h"
clOpenLinkedDoc::clOpenLinkedDoc()
{
    try
    {		
		
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
    }	
    catch(...)
    {
        printf("clOpenLinkedDoc::clOpenLinkedDoc() -> error ...");
    }
}
clOpenLinkedDoc::~clOpenLinkedDoc ()
{
	try
	{
	}
	catch(...)
	{
		
	}
}
int clOpenLinkedDoc::GetReturnParameters()
{
    try
    {
		return 0;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
			return -1;
    }	
    catch(...)
    {
		return -1;
    }
}

bool clOpenLinkedDoc::doMethod(const vector <QString> &paParametersType, const vector <QString> &paParameters)
{
	// Get and display the name of the computer.
	TCHAR infoBuf[INFO_BUFFER_SIZE];
	DWORD  bufCharCount = INFO_BUFFER_SIZE;
	GetComputerName(infoBuf,&bufCharCount);	
	
	try
	{
		//QApplication::setQuitOnLastWindowClosed(false);	
		QString loTableName = QString(paParameters.at(0));
		QString loObjectID = QString(paParameters.at(1));
		
		string loFileStruct;
		
		if (!meIceClientServer->getServerFileStructure(loFileStruct))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clOpenLinkedDoc::doMethod() -> Could not get the file structure path ...");
			return false;
		}
		
		if (loTableName.toUpper().compare(QString("LINKEDDOC")) == 0)
		{
			
			 QDesktopServices::openUrl(QUrl("file:///" + QString(loFileStruct.c_str()) + loTableName.toUpper() + QString("_") + loObjectID));
		}
		else
		{
			//Getting the current linked documents
			vector<std::string> loColumns;
			vector<std::string> loValue;
			QString loReturnMessage;
			
			loColumns.push_back("LINKED_DOCUMENTS");
			
			if(!meIceClientServer->getFromTableDatabaseById(    loTableName,
																loObjectID,
																loColumns,
																loValue,
																loReturnMessage))
			{
				meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clOpenLinkedDoc::doMethod() -> " + loReturnMessage);		
				return false;			
			}
			else
				meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clOpenLinkedDoc::doMethod() -> " + loReturnMessage);			
				
				
			QStringList loElements = QString(loValue.at(0).c_str()).remove("}").remove("{").split(",", QString::SkipEmptyParts);
					 
			for (int k = 0; k < loElements.size(); k++)
			{
				QDesktopServices::openUrl(QUrl("file:///" + QString(loFileStruct.c_str()) + QString("LINKEDDOC") + QString("_") + loElements.at(k)));
			}			
		}
		meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe",QString("clOpenLinkedDoc::doMethod-> explorer opened on right path"));
		return true;
	}
	catch(const std::exception& ex)
	{
		printf(ex.what());       
		return false;
	}
}
bool clOpenLinkedDoc::createPluginClass( clIceClientServer * paIceClientServer, clIceClientLogging * paIceClientLogging)	
{
    try
    {
		meIceClientServer = paIceClientServer;
		meIceClientLogging = paIceClientLogging;
		return true;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
			return false;
    }	
    catch(...)
    {
		return false;
    }
}