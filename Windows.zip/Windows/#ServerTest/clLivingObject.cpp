#define INFO_BUFFER_SIZE 32767
#include "clLivingObject.h"

clLivingObject::clLivingObject(clIceClientServer * paIceClientServer, clIceClientLogging *paIceClientLogging)
{
	try
	{
    meIceClientServer = paIceClientServer;
	meIceClientLogging = paIceClientLogging;
	
	//////// Getting the living object for this machine /////////////////////
	getLivingObjectsForThisWorkstation();
	
	
	}
	catch(...)
	{
		cout << "clLivingObject::clLivingObject -> failed" << endl;
		
	}
}

clLivingObject::~clLivingObject()
{

}
bool clLivingObject::getLivingObjectsForThisWorkstation()
{
	// Get and display the name of the computer.
	TCHAR infoBuf[INFO_BUFFER_SIZE];
	DWORD  bufCharCount = INFO_BUFFER_SIZE;
	GetComputerName(infoBuf,&bufCharCount);	
	
	try
	{
		////////////////////////////////////////// Getting the living objects machine ///////////////////////////////////////////////////////////////
		QString loTableName("living_obj_mach");
		vector <std::string> loProperties;
		vector <std::string> loValues;
		vector <std::string> loTypeValues;
		vector <std::string> loLogExp;
		vector <std::string> loReturnIds;
		QString loReturnMessage;
		
		loProperties.push_back(QString("WORKSTATION_NAME").toStdString());
		loValues.push_back(QString(infoBuf).toStdString());
		loTypeValues.push_back(QString("text").toStdString());
		loLogExp.push_back(QString("=").toStdString());
		
		if (!meIceClientServer->getFromTableDatbaseByProperty(loTableName,QString("0"),QString("0"),loProperties,loValues,loTypeValues,loLogExp,loReturnIds,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clLivingObject::getLivingObjectsForThisWorkstation() -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clLivingObject::getLivingObjectsForThisWorkstation() -> " + loReturnMessage);
		
		
		int loThreadNumber = 0;
		
		if (loReturnIds.size() > 0)
		{
			for (int i = 0; i < loReturnIds.size(); i++)
			{
				meThread[loThreadNumber] = new QThread();
				meLivingObjectMach[i] = new clLivingObjectMach(meIceClientServer, meIceClientLogging, QString(loReturnIds.at(i).c_str()));
				meLivingObjectMach[i]->moveToThread(meThread[loThreadNumber]);
				meThread[loThreadNumber]->start();
				loThreadNumber = loThreadNumber + 1;	
			}
		}
		////////////////////////////////////////// Getting the living objects location ///////////////////////////////////////////////////////////////
		QString loTableNameLocation("LIVING_OBJ_LOCATION");
		vector <std::string> loPropertiesLoc;
		vector <std::string> loValuesLoc;
		vector <std::string> loTypeValuesLoc;
		vector <std::string> loLogExpLoc;
		vector <std::string> loReturnIdsLoc;
		QString loReturnMessageLoc;
		
		loPropertiesLoc.push_back(QString("WORKSTATION_NAME").toStdString());
		loValuesLoc.push_back(QString(infoBuf).toStdString());
		loTypeValuesLoc.push_back(QString("text").toStdString());
		loLogExpLoc.push_back(QString("=").toStdString());
		
		if (!meIceClientServer->getFromTableDatbaseByProperty(loTableNameLocation,QString("0"),QString("0"),loPropertiesLoc,loValuesLoc,loTypeValuesLoc,loLogExpLoc,loReturnIdsLoc,loReturnMessageLoc))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clLivingObject::getLivingObjectsForThisWorkstation() -> " + loReturnMessageLoc);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clLivingObject::getLivingObjectsForThisWorkstation() -> " + loReturnMessageLoc);
				
		if (loReturnIdsLoc.size() > 0)
		{		
			for (int i = 0; i < loReturnIdsLoc.size(); i++)
			{
				
				meThread[loThreadNumber] = new QThread();
				meLivingObjectLocator[i] = new clLivingObjectLocator(meIceClientServer, meIceClientLogging, QString(loReturnIdsLoc.at(i).c_str()));
				meLivingObjectLocator[i]->moveToThread(meThread[loThreadNumber]);
				meThread[loThreadNumber]->start();
				loThreadNumber = loThreadNumber + 1;		
			}		
		}
		return true;
	}
	catch(...)
	{
		return false;
	}
}


