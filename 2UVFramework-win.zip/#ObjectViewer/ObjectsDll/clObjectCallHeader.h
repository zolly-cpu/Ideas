#pragma once
#include <Windows.h>
#include <QtCore/QString>
#include "clObjectCall.h"

typedef clObjectCall *(*CreateModuleObjectFn)();