#define INFO_BUFFER_SIZE 32767
#include "clSaveLinkedDoc.h"
clSaveLinkedDoc::clSaveLinkedDoc()
{
    try
    {		
		
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
    }	
    catch(...)
    {
        printf("clSaveLinkedDoc::clSaveLinkedDoc() -> error ...");
    }
}
clSaveLinkedDoc::~clSaveLinkedDoc ()
{
	try
	{
	}
	catch(...)
	{
		
	}
}
int clSaveLinkedDoc::GetReturnParameters()
{
    try
    {
		return 0;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
			return -1;
    }	
    catch(...)
    {
		return -1;
    }
}

bool clSaveLinkedDoc::doMethod(const vector <QString> &paParametersType, const vector <QString> &paParameters)
{
	// Get and display the name of the computer.
	TCHAR infoBuf[INFO_BUFFER_SIZE];
	DWORD  bufCharCount = INFO_BUFFER_SIZE;
	GetComputerName(infoBuf,&bufCharCount);	
	
	try
	{
		//QApplication::setQuitOnLastWindowClosed(false);	
		QString loTableName = QString(paParameters.at(0));
		QString loObjectID = QString(paParameters.at(1));
		
		meSaveLinkedDocUI = new clSaveLinkedDocUI(meIceClientServer,meIceClientLogging);
		meSaveLinkedDocUI->meObjectId = loObjectID;
		meSaveLinkedDocUI->meTableName = loTableName;
		
		
		
		
		meSaveLinkedDocUI->setAttribute(Qt::WA_DeleteOnClose);
		
		if (meSaveLinkedDocUI->exec() == 0)
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe",QString("Application closed"));
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe",QString("Application closed"));
			
		
		//qrCodeImage.save(QString("./QrCodes/" + loTableName + "_" + loObjectID + ".png"), "PNG", 100);
		meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe",QString("clSaveLinkedDoc::doMethod-> Doc saved for object id " + loTableName + "_" + loObjectID));
		return true;
	}
	catch(const std::exception& ex)
	{
		printf(ex.what());       
		return false;
	}
}
bool clSaveLinkedDoc::createPluginClass( clIceClientServer * paIceClientServer, clIceClientLogging * paIceClientLogging)	
{
    try
    {
		meIceClientServer = paIceClientServer;
		meIceClientLogging = paIceClientLogging;
		return true;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
			return false;
    }	
    catch(...)
    {
		return false;
    }
}