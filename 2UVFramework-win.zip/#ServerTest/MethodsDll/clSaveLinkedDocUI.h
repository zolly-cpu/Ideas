#ifndef CLSAVELINKEDDOCUI_H
#define CLSAVELINKEDDOCUI_H

#include <exception>
#include <string>
#include <iostream>

#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QVBoxLayout>
#include <QtCore/QFile>
#include <QtCore/QFileInfo>
#include <QtCore/QDateTime>
#include <QtWidgets/QFileDialog>





#include "clIceClientLogging.h"
#include "clIceClientServer.h"

using namespace std;

class clSaveLinkedDocUI : public QDialog
{

    Q_OBJECT;

public:

    clSaveLinkedDocUI(clIceClientServer * paIceClientServer, clIceClientLogging * paIceClientLogging, QWidget* paParent = 0, const char* paName = 0);
    ~clSaveLinkedDocUI ();

    enum { NumGridRows = 200, NumButtons = 2 };
    QLabel *meLabels[NumGridRows];
    QPushButton *meButtons[NumButtons];
	
	QVBoxLayout *meMainLayout;
	
	QString meObjectId;
	QString meTableName;
	
public slots:
    //Slots Camera setup
    void slotButtonSaveAssPressed();
    void slotButtonCancelPressed();
private:
    clIceClientLogging * meIceClientLogging;
    clIceClientServer * meIceClientServer;
	
};

#endif
