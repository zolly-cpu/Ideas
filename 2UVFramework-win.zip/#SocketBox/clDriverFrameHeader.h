#pragma once
#include <Windows.h>
#include <QtCore/QString>
#include "clDriverFrame.h"

typedef clDriverFrame *(*CreateModuleFn)();