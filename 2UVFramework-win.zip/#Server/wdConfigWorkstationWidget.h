/********************************************************************************
** Form generated from reading UI file 'wdConfigWorkstationWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDCONFIGWORKSTATIONWIDGET_H
#define WDCONFIGWORKSTATIONWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QSlider>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdConfigWorkstationWidget
{
public:
    QSlider *vtsPercentage;
    QProgressBar *pgbPercentage;
    QLineEdit *txtPercentage;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;

    void setupUi(QWidget *wdConfigWorkstationWidget)
    {
        if (wdConfigWorkstationWidget->objectName().isEmpty())
            wdConfigWorkstationWidget->setObjectName(QString::fromUtf8("wdConfigWorkstationWidget"));
        wdConfigWorkstationWidget->resize(814, 532);
        vtsPercentage = new QSlider(wdConfigWorkstationWidget);
        vtsPercentage->setObjectName(QString::fromUtf8("vtsPercentage"));
        vtsPercentage->setGeometry(QRect(550, 70, 22, 381));
        vtsPercentage->setOrientation(Qt::Vertical);
        vtsPercentage->setInvertedAppearance(true);
        pgbPercentage = new QProgressBar(wdConfigWorkstationWidget);
        pgbPercentage->setObjectName(QString::fromUtf8("pgbPercentage"));
        pgbPercentage->setGeometry(QRect(660, 70, 21, 381));
        pgbPercentage->setMaximum(99);
        pgbPercentage->setValue(0);
        pgbPercentage->setOrientation(Qt::Vertical);
        pgbPercentage->setInvertedAppearance(true);
        txtPercentage = new QLineEdit(wdConfigWorkstationWidget);
        txtPercentage->setObjectName(QString::fromUtf8("txtPercentage"));
        txtPercentage->setGeometry(QRect(620, 470, 61, 20));
        label = new QLabel(wdConfigWorkstationWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(530, 470, 91, 16));
        label_2 = new QLabel(wdConfigWorkstationWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 30, 71, 16));
        label_3 = new QLabel(wdConfigWorkstationWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(550, 30, 111, 16));
        verticalLayoutWidget = new QWidget(wdConfigWorkstationWidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(50, 50, 431, 431));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);

        retranslateUi(wdConfigWorkstationWidget);

        QMetaObject::connectSlotsByName(wdConfigWorkstationWidget);
    } // setupUi

    void retranslateUi(QWidget *wdConfigWorkstationWidget)
    {
        wdConfigWorkstationWidget->setWindowTitle(QApplication::translate("wdConfigWorkstationWidget", "Form", nullptr));
        label->setText(QApplication::translate("wdConfigWorkstationWidget", "Percentage [%]:", nullptr));
        label_2->setText(QApplication::translate("wdConfigWorkstationWidget", "Workstations:", nullptr));
        label_3->setText(QApplication::translate("wdConfigWorkstationWidget", "Configuration number:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdConfigWorkstationWidget: public Ui_wdConfigWorkstationWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDCONFIGWORKSTATIONWIDGET_H
