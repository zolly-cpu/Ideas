#pragma once
#include <QtCore/QString>
#include "clObjectCall.h"

typedef clObjectCall *(*CreateModuleObjectFn)();
