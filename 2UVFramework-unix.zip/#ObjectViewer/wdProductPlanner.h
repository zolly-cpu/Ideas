/********************************************************************************
** Form generated from reading UI file 'wdProductPlanner.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDPRODUCTPLANNER_H
#define WDPRODUCTPLANNER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdProductPlanner
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QTreeWidget *tvwMachineView;
    QTreeWidget *tvwProductView;
    QProgressBar *progressBar;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *btnPlan;
    QPushButton *btnRefresh;

    void setupUi(QWidget *wdProductPlanner)
    {
        if (wdProductPlanner->objectName().isEmpty())
            wdProductPlanner->setObjectName(QString::fromUtf8("wdProductPlanner"));
        wdProductPlanner->resize(882, 628);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(100);
        sizePolicy.setVerticalStretch(100);
        sizePolicy.setHeightForWidth(wdProductPlanner->sizePolicy().hasHeightForWidth());
        wdProductPlanner->setSizePolicy(sizePolicy);
        wdProductPlanner->setMaximumSize(QSize(16777215, 16777215));
        verticalLayout = new QVBoxLayout(wdProductPlanner);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetMaximumSize);
        tvwMachineView = new QTreeWidget(wdProductPlanner);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        tvwMachineView->setHeaderItem(__qtreewidgetitem);
        tvwMachineView->setObjectName(QString::fromUtf8("tvwMachineView"));

        horizontalLayout->addWidget(tvwMachineView);

        tvwProductView = new QTreeWidget(wdProductPlanner);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem();
        __qtreewidgetitem1->setText(0, QString::fromUtf8("1"));
        tvwProductView->setHeaderItem(__qtreewidgetitem1);
        tvwProductView->setObjectName(QString::fromUtf8("tvwProductView"));

        horizontalLayout->addWidget(tvwProductView);


        verticalLayout->addLayout(horizontalLayout);

        progressBar = new QProgressBar(wdProductPlanner);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(24);

        verticalLayout->addWidget(progressBar);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetMaximumSize);
        btnPlan = new QPushButton(wdProductPlanner);
        btnPlan->setObjectName(QString::fromUtf8("btnPlan"));

        horizontalLayout_3->addWidget(btnPlan);

        btnRefresh = new QPushButton(wdProductPlanner);
        btnRefresh->setObjectName(QString::fromUtf8("btnRefresh"));

        horizontalLayout_3->addWidget(btnRefresh);


        verticalLayout->addLayout(horizontalLayout_3);


        retranslateUi(wdProductPlanner);

        QMetaObject::connectSlotsByName(wdProductPlanner);
    } // setupUi

    void retranslateUi(QWidget *wdProductPlanner)
    {
        wdProductPlanner->setWindowTitle(QCoreApplication::translate("wdProductPlanner", "wdObjectView", nullptr));
        btnPlan->setText(QCoreApplication::translate("wdProductPlanner", "Plan", nullptr));
        btnRefresh->setText(QCoreApplication::translate("wdProductPlanner", "Refresh", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdProductPlanner: public Ui_wdProductPlanner {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDPRODUCTPLANNER_H
