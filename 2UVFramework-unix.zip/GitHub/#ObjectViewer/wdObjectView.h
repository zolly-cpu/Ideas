/********************************************************************************
** Form generated from reading UI file 'wdObjectView.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDOBJECTVIEW_H
#define WDOBJECTVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdObjectView
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QTreeWidget *tvwObjects;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *btnRefresh;

    void setupUi(QWidget *wdObjectView)
    {
        if (wdObjectView->objectName().isEmpty())
            wdObjectView->setObjectName(QString::fromUtf8("wdObjectView"));
        wdObjectView->resize(882, 628);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(100);
        sizePolicy.setVerticalStretch(100);
        sizePolicy.setHeightForWidth(wdObjectView->sizePolicy().hasHeightForWidth());
        wdObjectView->setSizePolicy(sizePolicy);
        wdObjectView->setMaximumSize(QSize(16777215, 16777215));
        verticalLayout = new QVBoxLayout(wdObjectView);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetMaximumSize);
        tvwObjects = new QTreeWidget(wdObjectView);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        tvwObjects->setHeaderItem(__qtreewidgetitem);
        tvwObjects->setObjectName(QString::fromUtf8("tvwObjects"));

        horizontalLayout->addWidget(tvwObjects);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetMaximumSize);
        btnRefresh = new QPushButton(wdObjectView);
        btnRefresh->setObjectName(QString::fromUtf8("btnRefresh"));

        horizontalLayout_3->addWidget(btnRefresh);


        verticalLayout->addLayout(horizontalLayout_3);


        retranslateUi(wdObjectView);

        QMetaObject::connectSlotsByName(wdObjectView);
    } // setupUi

    void retranslateUi(QWidget *wdObjectView)
    {
        wdObjectView->setWindowTitle(QCoreApplication::translate("wdObjectView", "wdObjectView", nullptr));
        btnRefresh->setText(QCoreApplication::translate("wdObjectView", "Refresh", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdObjectView: public Ui_wdObjectView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDOBJECTVIEW_H
