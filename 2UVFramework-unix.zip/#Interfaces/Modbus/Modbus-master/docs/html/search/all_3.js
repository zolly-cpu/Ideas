var searchData=
[
  ['dependencies_0',['Dependencies',['../index.html#autotoc_md4',1,'']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]]
];
