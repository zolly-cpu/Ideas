var searchData=
[
  ['what_0',['what',['../classMB_1_1ModbusException.html#a1af9903bea9caabdf35ad69ce17a682a',1,'MB::ModbusException']]],
  ['why_1',['Why',['../index.html#autotoc_md1',1,'']]],
  ['wont_20be_20it_20is_20preffered_20to_20use_20doxygen_20for_20code_20documentation_2',['The below API is not finished (propably wont be), it is preffered to use doxygen for code documentation.',['../index.html#autotoc_md11',1,'']]]
];
