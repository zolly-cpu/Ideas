var searchData=
[
  ['calculatecrc_0',['calculateCRC',['../namespaceMB_1_1CRC.html#a2a8e570461d56e3a269e2d1c242bcf2f',1,'MB::CRC::calculateCRC(const uint8_t *buff, std::size_t len)'],['../namespaceMB_1_1CRC.html#a2c9c245bb92560f18d3127961c3e2d5f',1,'MB::CRC::calculateCRC(const std::vector&lt; uint8_t &gt; &amp;buffer)'],['../namespaceMB_1_1utils.html#aa419ed339bbdacd4108fb5cc1cd14539',1,'MB::utils::calculateCRC(const uint8_t *buff, size_t len)'],['../namespaceMB_1_1utils.html#a102e7bc4008a2658a5db76a9b70bec97',1,'MB::utils::calculateCRC(const std::vector&lt; uint8_t &gt; &amp;buffer)']]],
  ['coil_1',['coil',['../classMB_1_1ModbusCell.html#a8d0771f1c9b700dfd479c03f427fc195',1,'MB::ModbusCell::coil()'],['../classMB_1_1ModbusCell.html#a431d6e379b18657ddbb2a84fcd947f83',1,'MB::ModbusCell::coil() const']]]
];
