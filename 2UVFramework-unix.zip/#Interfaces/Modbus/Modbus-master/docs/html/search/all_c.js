var searchData=
[
  ['reg_0',['reg',['../classMB_1_1ModbusCell.html#a2637cd2e9111044a55f512586fbbead4',1,'MB::ModbusCell::reg()'],['../classMB_1_1ModbusCell.html#abdc97b32e6c9c45bbb5f4a94a879333f',1,'MB::ModbusCell::reg() const']]]
];
