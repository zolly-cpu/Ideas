var searchData=
[
  ['connection_0',['Connection',['../classMB_1_1Serial_1_1Connection.html',1,'MB::Serial::Connection'],['../classMB_1_1TCP_1_1Connection.html',1,'MB::TCP::Connection']]]
];
